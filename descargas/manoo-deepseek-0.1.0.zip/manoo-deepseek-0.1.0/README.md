# Manoo para DeepSeek

Le da manos al agente de DeepSeek: **ve tu pantalla, mueve el mouse y escribe por
ti**, con barra en pantalla, aro para señalarte y voz que te va contando.

> **Hoy solo macOS.** Linux y Windows todavía no.

## Instalación en 3 pasos

```bash
cd manoo-deepseek-0.1.0
./instalar.sh                      # revisa requisitos, permisos y llave
./manoo.command                    # o: ./manoo "abre la Calculadora y calcula 6 por 7"
```

1. Corre `./instalar.sh` y dale a macOS los permisos que te pida (Accesibilidad,
   Grabación de pantalla y Monitoreo de entrada — el último es el del botón de pánico).
2. Ten una llave de DeepSeek: en `~/.config/manoo/deepseek.key`, en la variable
   `DEEPSEEK_API_KEY`, o la que ya tenga DeepSeek Harness en esta máquina.
3. Escribe lo que quieres, en español.

## Documentos

| Archivo | Qué es |
|---|---|
| `MANUAL_DE_USUARIO.md` | El manual completo: modos, barra, aro, voz, permisos, Free y Pro |
| `LICENCIA.txt` | La licencia de uso |
| `dsh/README.md` | Cómo usar Manoo **dentro de DeepSeek Harness** (herramientas MCP) |

## Qué hace y qué no

Hace lo de rutina por ti. **No** entra a bancos, brokers, cripto, gestores de
contraseñas ni SAT (ni los mira); **no** escribe contraseñas, PIN, tarjetas ni
códigos; y **el botón final que paga, firma, envía o publica lo das tú**. Eso no
está en un texto que el modelo pueda ignorar: está en el código, con pruebas.

Si tocas el mouse o el teclado, o presionas **Escape**, Manoo se detiene al instante.

## Licencia y compra

Manoo Gratis: 25 acciones por sesión. **Manoo Pro**: ilimitadas y con registro de
auditoría, **$49 USD/año** o **$6 USD/mes** en https://jamielgv.github.io/manoo.
La misma llave sirve para la versión de Claude y para esta.

---

Autor único: **Jamiel García Velázquez** · © 2026 · Todos los derechos reservados.
