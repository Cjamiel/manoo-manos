#!/bin/bash
# Manoo para DeepSeek · lanzador
# ---------------------------------------------------------------------------
# Doble clic en este archivo (o córrelo desde la Terminal) y escribe lo que
# quieres que Manoo haga. Habla español, señala con el aro y, si la voz está
# encendida, te lo va diciendo.
#
# Escribe «salir» para terminar.
#
# Autor: Jamiel García Velázquez · © 2026 · Todos los derechos reservados.
# ---------------------------------------------------------------------------

cd "$(dirname "$0")" || exit 1
export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"

# ¿En qué idioma le hablamos? El que la persona eligió en los ajustes, o el del sistema.
IDIOMA=auto
AJUSTES="$HOME/.config/manoo/ajustes.json"
if [ -f "$AJUSTES" ]; then
  grep -q '"idioma"[[:space:]]*:[[:space:]]*"es"' "$AJUSTES" && IDIOMA=es
  grep -q '"idioma"[[:space:]]*:[[:space:]]*"en"' "$AJUSTES" && IDIOMA=en
  grep -q '"idioma"[[:space:]]*:[[:space:]]*"zh"' "$AJUSTES" && IDIOMA=zh
fi
if [ "$IDIOMA" = auto ]; then
  case "${LC_ALL:-${LANG:-}}" in
    zh*) IDIOMA=zh ;;
    es*) IDIOMA=es ;;
    *)   IDIOMA=en ;;
  esac
fi
# t "español" "english" "中文"
t() { case "$IDIOMA" in zh) printf '%s' "$3" ;; en) printf '%s' "$2" ;; *) printf '%s' "$1" ;; esac; }

# ¿Trae Manoo su propio Node? (lo deja el instalador) Entonces se usa ese.
if [ -x "./node/bin/node" ]; then
  NODE="./node/bin/node"
  export PATH="$PWD/node/bin:$PATH"
else
  NODE="node"
fi

if ! command -v "$NODE" >/dev/null 2>&1 && ! [ -x "$NODE" ]; then
  echo "$(t "Falta Node.js. Bájalo de https://nodejs.org y vuelve a abrir esto." "Node.js is missing. Download it from https://nodejs.org and open this again." "缺少 Node.js。请从 https://nodejs.org 下载，然后重新打开这个。")"
  read -r -p "$(t "Enter para cerrar…" "Press Enter to close…" "按回车关闭…")" _
  exit 1
fi

echo "═══════════════════════════════════════════════════════"
echo "  MANOO para DeepSeek"
echo "═══════════════════════════════════════════════════════"
"$NODE" manoo.mjs --info 2>/dev/null | grep -E "Accesibilidad|Grabación|encontrada|viene de|Barra:|Switches:|Pro activo|Manoo gratis" | sed 's/^/  /'
echo
echo "  $(t "Escríbele lo que quieres. Por ejemplo:" "Type what you want. For example:" "把你想做的事写出来。比如：")"
echo "    $(t "abre la Calculadora y calcula 6 por 7" "open the Calculator and work out 6 times 7" "打开计算器，算一下 6 乘 7")"
echo "    $(t "ensename donde esta el boton de guardar   (sin ñ; no toca nada, te señala)" "teach me where the save button is   (it touches nothing, it points)" "教我保存按钮在哪里   (它什么都不碰，只指给你看)")"
echo "    $(t "hazlo sin preguntar: acomoda mis ventanas (modo hacer)" "just do it: tidy up my windows   (do-it mode)" "你来做：把我的窗口排好   (直接做模式)")"

echo "    $(t "salir" "quit" "退出")"
echo

while true; do
  printf '  > '
  IFS= read -r linea || break
  [ -z "$linea" ] && continue
  case "$linea" in
    salir|Salir|SALIR|q|Q) break ;;
  esac

  modo="asistir"
  tarea="$linea"
  # Se aceptan con acentos, sin acentos, con ñ o sin ella, y en inglés: hay
  # teclados (el inglés) que no tienen ni ñ ni acentos.
  case "$linea" in
    enséñame*|ensename*|ensename*|enséname*|muestrame*|muéstrame*|explicame*|explícame*|"teach me"*|"show me"*|教我*|示范*|告诉我*)
      modo="ensenar"; tarea="${linea#* }" ;;
    "hazlo sin preguntar"*|"just do it"*|你来做*|自己做*|不要问*)
      modo="hacer"; tarea="${linea#*preguntar}" ;;
    hazlo*|hazlotu*|"do it"*)
      modo="hacer"; tarea="${linea#* }" ;;
  esac
  [ -z "$tarea" ] && tarea="$linea"

  echo
  "$NODE" manoo.mjs --modo "$modo" "$tarea"
  echo
done

echo "  $(t "Listo. Si quieres cerrar la barra: pídele a Manoo «ajustes barra:false»." "Done. To close the bar: ask Manoo «ajustes barra:false»." "好了。想收起状态栏就说：ajustes barra:false")"

