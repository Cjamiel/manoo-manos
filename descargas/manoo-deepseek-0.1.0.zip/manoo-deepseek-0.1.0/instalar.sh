#!/bin/bash
# Manoo para DeepSeek · instalación
# ---------------------------------------------------------------------------
# Revisa lo que hace falta, te guía para dar los permisos de macOS y te deja
# todo listo para usar. No instala nada fuera de esta carpeta.
#
# Autor: Jamiel García Velázquez · © 2026 · Todos los derechos reservados.
# ---------------------------------------------------------------------------
set -u
AQUI="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$AQUI"

ok()   { printf "  ✅ %s\n" "$1"; }
bad()  { printf "  ❌ %s\n" "$1"; }
warn() { printf "  ⚠️  %s\n" "$1"; }

echo
echo "═══════════════════════════════════════════════════════"
echo "  MANOO para DeepSeek 0.1.0 · instalación"
echo "═══════════════════════════════════════════════════════"
echo
echo "▸ Requisitos"

FALLAS=0
if [ "$(uname)" != "Darwin" ]; then
  bad "Manoo hoy solo funciona en macOS"; FALLAS=$((FALLAS+1))
fi
if command -v node >/dev/null 2>&1; then
  NV="$(node -v | sed 's/^v//')"
  if [ "${NV%%.*}" -ge 18 ] 2>/dev/null; then ok "Node v$NV"; else
    bad "Node v$NV (hace falta 18 o más)"; FALLAS=$((FALLAS+1)); fi
else
  bad "Node.js no está instalado. Bájalo de https://nodejs.org"; FALLAS=$((FALLAS+1))
fi
[ -x "$AQUI/bin/manoo-ax" ] && ok "puente nativo (accesibilidad, mouse y teclado)" || { bad "falta bin/manoo-ax"; FALLAS=$((FALLAS+1)); }
[ -x "$AQUI/bin/manoo-ui" ] && ok "barra, aro, voz y paro de emergencia" || { bad "falta bin/manoo-ui"; FALLAS=$((FALLAS+1)); }
[ "$FALLAS" -gt 0 ] && { echo; echo "Faltan $FALLAS cosa(s). Resuélvelas y vuelve a correr esto."; exit 1; }

echo
echo "▸ Permisos de macOS"
node src/manoo.mjs --info 2>/dev/null | grep -E "Accesibilidad$|Grabación de pantalla$" | sed 's/^ */  /'
echo "     Configuración del Sistema → Privacidad y seguridad, y activa la app desde"
echo "     donde corres Manoo (Terminal, iTerm…) en:"
echo "       · Accesibilidad        (mover el mouse, escribir y acomodar ventanas)"
echo "       · Grabación de pantalla (las capturas; sin esto salen negras)"
echo "       · Monitoreo de entrada  (EL BOTÓN DE PÁNICO: que se detenga si tocas el mouse)"

VIGIA="$(./bin/manoo-ui vigilar < /dev/null 2>&1 | head -1)"
case "$VIGIA" in
  *permiso_monitoreo*|*"no pude crear el vigía"*) warn "Falta Monitoreo de entrada: sin él, Manoo NO se detiene al tocar el mouse" ;;
  *'"listo":true'*) ok "el botón de pánico funciona (Escape y tocar el mouse detienen a Manoo)" ;;
  *) warn "no pude comprobar el botón de pánico" ;;
esac

echo
echo "▸ Llave de DeepSeek"
mkdir -p ~/.config/manoo 2>/dev/null
LLAVE="$(node src/manoo.mjs --info 2>/dev/null | grep -A1 'Credencial de DeepSeek' | tail -1 | sed 's/^ *//')"
LLAVE="${LLAVE#✅ }"
case "$LLAVE" in
  encontrada*) ok "$LLAVE" ;;
  *) warn "todavía no hay llave"
     echo "     Se guarda así (una sola vez):"
     echo "       printf '%s' 'TU_LLAVE' > ~/.config/manoo/deepseek.key && chmod 600 ~/.config/manoo/deepseek.key"
     echo "     La sacas de https://platform.deepseek.com/api_keys"
     echo "     (Si ya usas DeepSeek Harness en esta máquina, Manoo la toma de ahí solo.)" ;;
esac

echo
echo "▸ Licencia"
node src/manoo.mjs --info 2>/dev/null | grep -A1 '▸ Licencia' | tail -1 | sed 's/^ */  /'

echo
echo "═══════════════════════════════════════════════════════"
echo "  Listo. Ahora:"
echo
echo "    ./manoo.command                        (te va pidiendo tareas)"
echo "    ./manoo \"abre la Calculadora y calcula 6 por 7\""
echo "    ./manoo --modo ensenar \"muéstrame dónde guardo\""
echo
echo "  Empieza con algo aburrido: la calculadora. Nunca bancos,"
echo "  correo ni datos reales mientras lo pruebas."
echo
echo "  El manual completo está en MANUAL_DE_USUARIO.md"
echo "  Para usarlo dentro de DeepSeek Harness: dsh/README.md"
echo "═══════════════════════════════════════════════════════"
echo
