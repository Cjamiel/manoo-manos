# Manual de usuario — Manoo para DeepSeek

Manoo le da manos al agente de DeepSeek: **ve tu pantalla, mueve el mouse y escribe
por ti**. Tiene barra en pantalla, un aro para señalarte las cosas y voz que te va
contando lo que hace.

Todo corre en tu computadora. Lo que Manoo ve **va a DeepSeek**, que lo procesa y
lo guarda en China (igual que cualquier mensaje que le escribas). Manoo no manda
nada a servidores nuestros.

> **Hoy solo funciona en macOS.** Linux y Windows todavía no.

---

## Requisitos

- **macOS** (probado en macOS 12 y posteriores)
- **Node.js 18 o más** — https://nodejs.org
- Una **llave de DeepSeek**. Si ya usas DeepSeek Harness en esta computadora, Manoo
  la toma de ahí solo. Si no, la sacas en https://platform.deepseek.com/api_keys

---

## Instalación

```bash
cd manoo-deepseek-0.1.0
./instalar.sh
```

El instalador revisa todo, te dice qué falta y **te guía paso a paso** para darle a
macOS los permisos que necesita. Al final te dice cómo empezar.

### Permisos que debes dar en macOS

En **Configuración del Sistema → Privacidad y seguridad**, busca la app desde donde
corres Manoo (Terminal, iTerm…) y actívala en cada una de estas:

1. **Accesibilidad** — para que Manoo pueda mover el mouse, escribir y acomodar
   ventanas.
2. **Grabación de pantalla** — para que pueda tomar capturas. Sin esto, las capturas
   salen negras (leer el texto de las ventanas sí funciona).
3. **Monitoreo de entrada** — para el **botón de pánico**: que Manoo se detenga en
   cuanto tocas el mouse o el teclado. **Sin este permiso el paro no funciona.**

Si algo dejó de funcionar después de una actualización de macOS, revisa primero que
estos tres permisos sigan encendidos: macOS a veces los apaga solo.

### La ventana que pregunta por cada app

La primera vez que Manoo toca una app, sale una ventana que dice
**«¿Manoo puede usar «Calculadora»?»** y un aro brillante señala el botón **Permitir**.
Esa pregunta es la protección más importante que tienes: Manoo no toca nada sin tu sí.

- Pica **Permitir** y Manoo sigue solo con lo que le pediste. No tienes que hacer nada más.
- Si picas **Rechazar** (o aprietas Escape), Manoo no toca esa app y te lo dice.
- Si no contestas, se cierra sola: **no** cuenta como permiso.
- Un «no» dura **dos minutos**; después te puede volver a preguntar.
- No hay ninguna opción para saltarse esto, ni en la app ni en la configuración: es a propósito.

Si no ves la ventana, mira si quedó detrás de otra. Y si el aro no te señala el botón,
pídele a Manoo: «apúntame el botón Permitir».

---

## Cómo se usa

```bash
./manoo "abre la Calculadora y calcula 6 por 7"
```

O con doble clic en **`manoo.command`**, que te va pidiendo tareas:

```
> abre la Calculadora y calcula 6 por 7
> enséñame dónde está el botón de guardar
> hazlo sin preguntar: acomoda mis ventanas
> salir
```

---

## Los tres modos

| Escribes… | Modo | Qué hace |
|---|---|---|
| «ayúdame», «hazlo», «no sé cómo» | **asistir** (por defecto) | Hace **todo lo de rutina**: abrir apps, escribir direcciones, navegar, llenar campos, dar clic en «Siguiente». A ti te deja solo lo sensible, la decisión final y lo que no puede hacer |
| «enséñame», «cómo le hago», «muéstrame» | **enseñar** | **No toca nada.** Te señala con el aro dónde está, te explica en palabras sencillas y espera a que tú lo hagas. Después te dice si le atinaste |
| «hazlo tú», «just do it» | **hacer** | Igual que asistir, pero sin pedirte permiso en los pasos de rutina |

Si no queda claro qué quieres, asume **asistir**.

A mano: `./manoo --modo ensenar "muéstrame cómo cambiar el fondo"`.

---

## Qué verás mientras Manoo trabaja

- **La barra**, abajo a la izquierda, chiquita (la mano); se despliega hacia arriba
  con **+** sin moverse. Sus switches: **Voz, Cursor, Dividir, Zoom, Pausa**.
  - Se queda visible siempre que uses Manoo; con **✕** solo se oculta en esa sesión.
  - Tocar la barra **no** detiene a Manoo. Solo **Pausa** lo detiene.
- **El aro**: un anillo que respira, con una etiqueta («Aquí: Guardar»), para
  señalarte exactamente dónde picar sin moverse tu mouse.
- **El cursor neón**: mientras Manoo actúa, el puntero se ve como una mano de malla
  brillante, para que sepas de un vistazo que el mouse se está moviendo solo.
- **La pantalla se divide sola**: el chat de un lado y la app que Manoo maneja del
  otro, para que veas todo. Al terminar, las ventanas vuelven a como estaban.

---

## El botón de pánico: tú siempre tienes el control

Manoo vigila el mouse y el teclado de **todo el sistema**:

- Si **tocas el mouse o el teclado** mientras está actuando, **se detiene** y te avisa.
- La tecla **Escape** lo detiene siempre.
- Vuelve a pedirle que continúe cuando quieras: no pierdes nada, solo se pausó.

---

## Niveles: Gratis y Pro

| | Gratis | Pro |
|---|---|---|
| Acciones | 25 por sesión | **Ilimitadas** |
| Registro de auditoría local | No | **Sí** (`~/.local/share/manoo/audit-deepseek.log`) |
| Nivel de explicación | Principiante o avanzado | Igual |
| Precio | $0 | **$49 USD/año** o **$6 USD/mes** |

La **misma licencia de Manoo Pro sirve para la versión de Claude y para esta**: si
ya compraste, no vuelves a pagar.

### Comprar y activar

1. Entra a **https://jamielgv.github.io/manoo** y dale a «Obtener Pro». El pago se
   procesa con Stripe y tu llave te llega por correo.
2. Pídele a Manoo: *«activa mi licencia: TU-LLAVE»*.
3. Queda guardada en `~/.config/manoo/license.key` — no la repites cada vez.

Para revisar tu estado: *«¿cuál es mi estado de licencia?»*.

---

## Lo que Manoo NO hace (y no se puede desactivar)

Estas reglas **viven en el código**, no en un texto que el modelo pueda ignorar:

- **No entra a bancos, brokers, cripto, gestores de contraseñas ni al SAT.** Si la
  app está en la lista, o si el **título de la ventana** lo delata (un banco abierto
  dentro del navegador), Manoo no la toca **ni la mira**: no toma capturas ni lee su
  pantalla. Solo te guía con palabras y con el aro.
- **Nunca escribe contraseñas, PIN, tarjetas ni códigos de un solo uso.**
- **El botón final que paga, transfiere, firma, publica o envía lo das tú.** Manoo te
  lo señala con el aro y espera tu clic.
- **La primera vez que usa una app te pide permiso** con una ventana (una vez por
  sesión). Si dices que no, no insiste en 2 minutos.
- Las teclas y el texto **solo van a la app que está manejando**: si otra ventana se
  pone al frente sola, la regresa o no escribe.
- Cada acción queda anotada en tu registro local (Pro).

---

## La voz

- Se prende y se apaga con el switch **🔊 Voz** de la barra, o pidiéndoselo.
- Nunca lee en voz alta números largos (tarjetas, CLABE, códigos, teléfonos).
- Si tu Mac no tiene una voz en español, Manoo no lee español con voz inglesa: te
  dice cómo agregarla (Configuración del Sistema → Accesibilidad → Contenido leído
  → Voz del sistema → Administrar voces → Español (México), Paulina).

---

## El idioma

Manoo habla español si tu sistema está en español, e inglés si está en otro idioma.
También puedes elegirlo: *«háblame en inglés»* / *«en español»* / *«automático»*.

---

## Preguntas frecuentes

**¿Manoo manda mis capturas a algún lado?**
A DeepSeek, que es quien piensa. Manoo **no** tiene servidor propio: lo que ve va al
modelo, igual que el texto que le escribes, y DeepSeek lo procesa y lo guarda en
China. El registro de auditoría de Pro se queda en tu máquina.

**¿Qué pasa si muevo el mouse sin querer?**
Se detiene en el siguiente paso y te avisa. Vuelve a pedirle que continúe.

**¿Por qué me pide permiso para una app?**
Para que **tú** decidas qué puede usar. Se pregunta una vez por app y sesión; un «no»
dura 2 minutos.

**¿Puedo usar Manoo en la versión de Claude con la misma licencia?**
Sí. Manoo para Claude y Manoo para DeepSeek comparten licencia y los mismos switches.

**¿Cómo lo desinstalo?**
Borra la carpeta `manoo-deepseek-0.1.0` y, si quieres, `~/.config/manoo`. No queda nada más
fuera de ahí.

---

## Soporte

Corporación Jamiel — jamiel.garcia.velazquez@gmail.com

Autor único: **Jamiel García Velázquez** · © 2026 · Todos los derechos reservados.
