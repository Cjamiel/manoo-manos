---
name: manoo
description: >
  Le da manos a DeepSeek sobre esta computadora: ver la pantalla, mover el mouse, escribir y
  controlar ventanas, con barra en pantalla, aro para señalar y voz. Úsalo cuando la persona pida
  que hagas algo EN la computadora en vez de explicárselo: «ábreme la calculadora», «llena este
  formulario», «enséñame dónde está guardar», «búscame tal cosa en el navegador». Hoy solo macOS.
---

# Manoo — manos para DeepSeek

Las herramientas llegan como `mcp__manoo__…`. Las importantes:

| Herramienta | Para qué |
|---|---|
| `mcp__manoo__leer_texto` | **Mira primero aquí.** Lee el árbol de accesibilidad: botones y campos con su nombre exacto. No gasta imagen. |
| `mcp__manoo__captura` | Foto de la pantalla (o de una región, para hacer zoom al texto chico). |
| `mcp__manoo__clic_elemento` | Pica por **nombre** («Guardar», «Siguiente»). Preferida sobre coordenadas. |
| `mcp__manoo__clic` | Solo si el elemento no tiene nombre. Usa las coordenadas de `leer_texto` tal cual. |
| `mcp__manoo__escribir` / `pegar_texto` | Texto en el campo con el cursor. `pegar_texto` para direcciones y rutas. |
| `mcp__manoo__esperar_a` | Espera a que aparezca un texto o elemento, **sin** tomar capturas. |
| `mcp__manoo__apuntar` | **El aro**: señala un punto con una etiqueta, sin tocar nada. Para enseñar o entregar un paso. |
| `mcp__manoo__decir` | Lo dice en voz alta (si la voz está encendida). |
| `mcp__manoo__entregar_pantalla` + `esperar_clic_persona` | Para un paso que solo la persona debe dar (contraseña, pago, publicar). |
| `mcp__manoo__terminar` | Cierra la tarea y deja las ventanas como estaban. |

## El ciclo

1. **Mira antes de actuar**: `leer_texto` (y `captura` solo si necesitas el acomodo).
2. **Una acción por paso**, narrando en una frase corta lo que vas a hacer.
3. **Verifica** después de cada acción, leyendo otra vez.
4. Si el mismo paso falla dos veces, **para y pregunta**.

## Reglas que Manoo aplica en código (no las pelees)

- No entra a bancos, brokers, cripto, gestores de contraseñas ni SAT: solo guía con palabras.
- Nunca escribe contraseñas, PIN, tarjetas ni códigos: eso lo hace la persona con el aro.
- El botón final que paga, firma, envía o publica lo da la persona.
- La primera vez que usa una app, pide permiso con una ventana (una vez por sesión).
- Si la persona toca el mouse, el teclado o presiona Escape, Manoo se detiene al instante.
- Las teclas y el texto solo van a la app que estás manejando.

## Coordenadas

`leer_texto` y `ventanas` dan **puntos de pantalla**: pásalos a `clic` tal cual. Si el número lo
leíste de una **captura**, dilo: `clic` con `espacio:"imagen"`. No mezcles los dos: el clic cae al
doble o a la mitad.
