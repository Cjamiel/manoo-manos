// Manoo para DeepSeek Harness · punto de entrada del bundle
// ---------------------------------------------------------------------------
// Este paquete no trae código de agente: lo que hace es CONECTAR el servidor
// MCP de Manoo (app/src/mcp.mjs) al harness, con el puente oficial
// @deepseek-ai/dsh-mcp-client. El trabajo lo hace ese puente; aquí solo se
// declara (cordis.patch.yml).
//
// Se deja el archivo porque un bundle de DSH necesita un paquete válido con
// main; no registra nada por su cuenta.
//
// Autor: Jamiel García Velázquez · © 2026 · Todos los derechos reservados.
// ---------------------------------------------------------------------------

export default function manooDeepSeek() {
  // Nada que registrar: las herramientas de Manoo llegan por MCP y el harness
  // las expone como mcp__manoo__<herramienta>.
  return {};
}
