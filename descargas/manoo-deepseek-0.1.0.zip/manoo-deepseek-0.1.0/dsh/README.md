# Manoo para DeepSeek Harness

Le da manos al agente de DeepSeek dentro del harness: ve la pantalla, mueve el mouse, escribe y
acomoda ventanas — con **barra en pantalla**, **aro para señalar** y **voz**.

Este paquete no trae código de agente: **conecta el servidor MCP de Manoo** con el puente oficial
`@deepseek-ai/dsh-mcp-client`. Las herramientas aparecen como `mcp__manoo__<herramienta>`.

> **Hoy solo macOS.** El puente nativo está escrito para macOS (accesibilidad, CGEvent y capturas).
> Linux y Windows están en el proyecto de Manoo, no aquí.

## Requisitos

- macOS con Node 18+
- Los permisos de **Accesibilidad**, **Grabación de pantalla** y **Monitoreo de entrada**
  (el último es el del botón de pánico: si tocas el mouse, Manoo se detiene)
- Una llave de DeepSeek: en `~/.config/manoo/deepseek.key`, en `DEEPSEEK_API_KEY`, o la que ya
  tenga el propio harness en esta máquina

## Instalación

```bash
cd dsh
./instalar-dsh.sh              # revisa todo y te dice qué pegar
./instalar-dsh.sh --aplicar    # lo escribe en tu perfil de DSH (con respaldo)
```

Después reinicia DeepSeek Harness. La forma manual es pegar esto al final de
`~/.dsh/profiles/web/cordis.patch.yml`:

```yaml
- insert:
    - id: mcp-manoo
      name: '@deepseek-ai/dsh-mcp-client'
      config:
        serverName: manoo
        transport: stdio
        command: node
        args: ['/ruta/a/manoo-deepseek/app/src/mcp.mjs']
        toolCallTimeoutMs: 180000
```

O como plugin del harness, si tienes el CLI:

```bash
dsh plugin --profile web add /ruta/a/manoo-deepseek/dsh
```

## Qué NO hace

- No entra a bancos, brokers, cripto, gestores de contraseñas ni SAT: solo guía con palabras.
- No escribe contraseñas, PIN, tarjetas ni códigos.
- No pica el botón final que paga, firma, envía o publica: eso lo da la persona.

Eso no vive en el prompt: vive en el código (`app/src/guard.mjs`) y hay pruebas que lo comprueban.

## Cómo se apaga

Quita el bloque `mcp-manoo` de `cordis.patch.yml` (o el paquete del perfil) y reinicia el harness.
La barra se cierra con su ✕, que solo la oculta en esa sesión.

---

Autor: **Jamiel García Velázquez** · © 2026 · Todos los derechos reservados.
