#!/bin/bash
# Manoo para DeepSeek Harness · instalador
# ---------------------------------------------------------------------------
# Deja Manoo disponible dentro de DeepSeek Harness como herramientas MCP
# (mcp__manoo__…). Hace tres cosas:
#   1. Comprueba que Manoo funciona (puente nativo, permisos y llave).
#   2. Escribe cordis.patch.yml con la ruta real de esta copia.
#   3. Te da (o aplica, con --aplicar) la línea que va en tu perfil de DSH.
#
# Uso:
#   ./instalar-dsh.sh             solo revisa y te dice qué pegar
#   ./instalar-dsh.sh --aplicar   además lo escribe en tu perfil (con respaldo)
#
# Autor: Jamiel García Velázquez · © 2026 · Todos los derechos reservados.
# ---------------------------------------------------------------------------
set -u
AQUI="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MANOO="$(cd "$AQUI/.." && pwd)"
PERFIL="${DSH_PERFIL:-$HOME/.dsh/profiles/web}"
PARCHE="$PERFIL/cordis.patch.yml"

ok()   { printf "  ✅ %s\n" "$1"; }
bad()  { printf "  ❌ %s\n" "$1"; }
warn() { printf "  ⚠️  %s\n" "$1"; }

echo
echo "═══════════════════════════════════════════════════════"
echo "  MANOO para DeepSeek Harness"
echo "═══════════════════════════════════════════════════════"

if ! command -v node >/dev/null 2>&1; then
  bad "Falta Node.js. Bájalo de https://nodejs.org"; exit 1
fi
ok "Node $(node -v)"

# 1. ¿Manoo funciona?
if [ -x "$MANOO/app/bin/manoo-ax" ]; then ok "puente nativo compilado"; else
  warn "falta el puente nativo: corre $MANOO/app/instalar.sh"; fi
if node "$MANOO/app/src/mcp.mjs" </dev/null >/dev/null 2>&1; then ok "el servidor MCP arranca"; else
  bad "el servidor MCP no arranca"; exit 1; fi

# 2. El parche con la ruta real
python3 - "$AQUI/cordis.patch.yml" "$MANOO" <<'PY'
import sys, pathlib
ruta, manoo = sys.argv[1], sys.argv[2]
p = pathlib.Path(ruta)
t = p.read_text(encoding="utf8")
import re
t = re.sub(r"args: \['[^']*'\]", f"args: ['{manoo}/app/src/mcp.mjs']", t)
p.write_text(t, encoding="utf8")
print(f"  ✅ cordis.patch.yml apunta a {manoo}/app/src/mcp.mjs")
PY

# 3. El perfil de DSH
echo
if [ ! -f "$PARCHE" ]; then
  warn "no encontré tu perfil de DSH en $PARCHE"
  echo "     Pega esto en tu capa de parche (o corre este script con DSH_PERFIL=…):"
else
  if grep -q "mcp-manoo" "$PARCHE" 2>/dev/null; then
    ok "tu perfil ya tiene a Manoo conectado"
  else
    echo "  Así queda tu perfil de DSH (esto es lo que hay que agregar):"
  fi
fi
echo
sed 's/^/     /' "$AQUI/cordis.patch.yml" | sed -n '/- insert:/,$p'
echo
echo "  Pégalo al FINAL de: $PARCHE"
echo "  (o corre:  $0 --aplicar )"
echo

if [ "${1:-}" = "--aplicar" ]; then
  if [ ! -f "$PARCHE" ]; then bad "no existe $PARCHE: no lo puedo aplicar"; exit 1; fi
  RESPALDO="$PARCHE.respaldo-$(date +%Y%m%d-%H%M%S)"
  cp "$PARCHE" "$RESPALDO" && ok "respaldo en $RESPALDO"
  if grep -q "mcp-manoo" "$PARCHE"; then
    ok "ya estaba aplicado: no toco nada"
  else
    { echo; sed -n '/- insert:/,$p' "$AQUI/cordis.patch.yml"; } >> "$PARCHE"
    ok "aplicado. Reinicia DeepSeek Harness para que aparezcan las herramientas mcp__manoo__…"
  fi
fi

echo "═══════════════════════════════════════════════════════"
echo "  Después de reiniciar, pídele a DeepSeek:"
echo "     «lee lo que dice mi ventana»        → mcp__manoo__leer_texto"
echo "     «enséñame dónde está Guardar»       → aro, sin tocar nada"
echo "     «abre la Calculadora y suma 6+7»    → lo hace y te lo cuenta"
echo "═══════════════════════════════════════════════════════"
echo
